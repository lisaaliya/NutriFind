import React from 'react';
import { Leaf, User, ChefHat } from 'lucide-react';

interface NavbarProps {
  onHomeClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onHomeClick }) => {
  
  const handleFeatureNotReady = (e: React.MouseEvent, featureName: string) => {
    e.preventDefault();
    alert(`🚧 Maaf, fitur "${featureName}" masih dalam tahap pengembangan.\n\nNantikan update eksklusif selanjutnya dari Lisa Aliya!`);
  };

  const handleHome = (e: React.MouseEvent) => {
    e.preventDefault();
    onHomeClick();
  };

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md shadow-sm border-b border-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo - Clickable to Home */}
          <div 
            className="flex items-center gap-2 cursor-pointer group" 
            onClick={() => onHomeClick()}
          >
            <div className="bg-sage-100 p-1.5 rounded-lg group-hover:bg-sage-200 transition-colors">
                <ChefHat className="h-6 w-6 text-sage-600" />
            </div>
            <div className="flex flex-col">
                <span className="text-lg font-bold text-sage-600 tracking-tight leading-none group-hover:text-sage-800 transition-colors">NutriFind.</span>
                <span className="text-[10px] text-stone-500 font-medium tracking-wide">by Lisa Aliya</span>
            </div>
          </div>

          <nav className="flex items-center space-x-6">
            <a 
                href="#" 
                onClick={handleHome}
                className="hidden sm:block text-stone-600 hover:text-sage-600 font-medium transition-colors text-sm"
            >
                Beranda
            </a>
            <a 
                href="#" 
                onClick={(e) => handleFeatureNotReady(e, "Resep Premium")}
                className="hidden sm:block text-stone-600 hover:text-sage-600 font-medium transition-colors text-sm"
            >
                Resep Premium
            </a>
            <div 
                onClick={(e) => handleFeatureNotReady(e, "Login Member")}
                className="flex items-center gap-2 text-stone-600 cursor-pointer hover:text-sage-600 bg-stone-100 px-3 py-1.5 rounded-full transition-colors hover:bg-sage-100"
            >
                <User className="h-4 w-4" />
                <span className="text-xs font-bold">Masuk</span>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};